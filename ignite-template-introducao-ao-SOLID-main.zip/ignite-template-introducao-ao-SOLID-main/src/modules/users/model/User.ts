import { v4 as uuidV4 } from "uuid";

class User {
  // Complete aqui
}

export { User };
